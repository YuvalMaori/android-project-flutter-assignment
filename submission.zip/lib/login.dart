import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth_repository.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final passwordController = TextEditingController();
  final emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final AuthRepository authRepository = Provider.of<AuthRepository>(context, listen: false);
    return Scaffold(
        appBar: AppBar(
          title: Text('Login'),
        ),
        body: Padding(
            padding: EdgeInsets.all(10),
            child: ListView(
                children: <Widget>[
                  Container(
                      padding: EdgeInsets.all(10),
                      child: Text(
                        'Welcome to startup Names Generator, please log in below',
                      )),
                  Container(
                      padding: EdgeInsets.all(10),
                      child: TextField(
                        controller: emailController,
                        decoration: InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Email',
                        ),
                      )),
                  Container(
                      padding: EdgeInsets.all(10),
                      child: TextField(
                        controller: passwordController,
                        decoration: InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Password',
                        ),
                      )),
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.red),
                    child: TextButton(
                      onPressed: () async {
                        bool isLogin = await authRepository.signIn(emailController.text, passwordController.text);
                        if (isLogin) {
                          Navigator.pushNamed(context, '/');
                        }
                        else {
                          final snackBar = SnackBar(
                            content: Text(
                                'There was an error logging into the app'),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        }
                      },

                      child: Text(
                        'Log in',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  Center(
                      child: Consumer<AuthRepository> (builder: (context, auth, _)
                        { return (authRepository.status == Status.Authenticating) ? CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(Colors.black)) : Text("");}
                      )
                  )
                ]
            )
        )

    );
  }
}
